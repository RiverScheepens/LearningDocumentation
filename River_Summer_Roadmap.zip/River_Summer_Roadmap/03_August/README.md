### ✅ August

- [ ] Project #2: More ambitious C++ project (maybe multithreaded or sim-based)
- [ ] Convert your personal story into a readable essay (I’ll help polish)
- [ ] Continue journaling and GitHub updates
- [ ] Prepare a school-year CS goal list (Ex: compete in USACO, join a club, tutor a peer)
- [ ] Reach out to a teacher early in 10th grade for mentorship or recommendation later