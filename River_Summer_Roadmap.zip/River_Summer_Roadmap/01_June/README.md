### ✅ June (Last 2 Weeks of 9th Grade)

- [ ] Finish any remaining schoolwork strong (keep those grades high)
- [ ] Finalize GitHub repo for your first C++ project (even simple)
- [ ] Reflect: Write your **“Why I changed”** story as a draft
- [ ] Begin journaling your CS learning weekly (private repo or markdown file)