### ✅ July

- [ ] Finish *C++ Primer* (set a chapter/week pace)
- [ ] Princeton CS course → Aim for 1–2 lectures per week
- [ ] Project #1: TCP tool / file compressor / system-level sim
- [ ] Start your personal GitHub README (like a portfolio)
- [ ] Read **1 book**: Suggested — *Hackers: Heroes of the Computer Revolution* or *Road to Serfdom* (short version)

**Optional Bonus:**
- Submit your project to an online coding forum or get feedback from a community